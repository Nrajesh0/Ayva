from pathlib import Path
import re, json, subprocess, hashlib, collections, xml.etree.ElementTree as ET, zipfile, csv, tomllib
ROOT=Path('/workspace/Ayva'); OUT=Path('/workspace/artifacts/run-atlas'); BASE='app/src/main/java/com/focusbyrj/app/'
TRACKED=subprocess.check_output(['git','ls-files'],cwd=ROOT,text=True).splitlines()
COMMIT=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
LABELS={'shell':'App shell & navigation','focus':'Focus, blocking & routines','tasks':'Tasks, dates & work sessions','habits':'Habits & pausing','notes':'Notes, editor & media','chat':'Chat, planning & games','learning':'Learning & vocabulary','profile':'Profile, rewards & Pro','settings':'Settings, themes & permissions','widgets':'Home-screen widgets','protection':'Encryption, backup & recovery','voice':'Voice capture & transcription','platform':'Android services & notifications','build':'Build, tools & delivery','docs':'Documentation & evidence','assets':'Shared media & resource data','tests':'Verification tests'}
def module(path):
 p=path.lower(); n=Path(path).stem.lower()
 if path.startswith(BASE) and (Path(path).name in ['FocusApplication.kt','MainActivity.kt','FocusBottomBar.kt'] or '/ui/navigation/' in p):return 'shell'
 if Path(path).name in ['AppRepository.kt','DashboardScreen.kt','CustomCategoryManager.kt','CustomCategoryEditor.kt','CategoryEditorHelper.kt','BoundaryControls.kt','AppModeSection.kt','CustomRestrictionSection.kt']:return 'focus'
 if Path(path).name in ['DictionaryBookmark.kt','FullscreenSolutionsView.kt']:return 'learning'
 if Path(path).name in ['BubbleIconManager.kt','BubbleIconPicker.kt','AssistantPlanReceipt.kt','TalkActionChips.kt','CatMagicRiveView.kt']:return 'chat'
 if Path(path).name in ['DataRecoveryScreen.kt','DataRecoveryTools.kt']:return 'protection'
 if Path(path).name in ['SecurityScreen.kt','ScreenCaptureProtection.kt','BackupDialogs.kt','AyvaNotificationColorsDialog.kt','AyvaAlertTheme.kt']:return 'settings'
 if Path(path).name in ['AppLogger.kt','CrashHandler.kt','DiagnosticManager.kt']:return 'platform'
 if '/jniLibs/' in path or '/assets/conversation/' in path:return 'chat'
 if '/assets/dictionary/' in path or path.endswith('/assets/vocab.db'):return 'learning'
 if path.endswith('.riv'):return 'chat'
 if path.endswith('.lottie') and 'habb' in n:return 'habits'
 if '/schemas/' in path:return 'protection'
 if p.startswith(('tools/','.github/','gradle/')) or path in ['build.gradle.kts','app/build.gradle.kts','settings.gradle.kts','gradle.properties','gradlew','gradlew.bat']:return 'build'
 if p.startswith('docs/') or path in ['README.md','LICENSE','TRADEMARK.md']:return 'docs'
 if p.startswith('app/src/test/') or p.startswith('app/src/androidTest/'):return 'tests'
 if '/widget/' in p or '/res/layout/widget_' in p or '/res/xml/' in p and 'widget' in p:return 'widgets'
 if '/util/backup/' in p or '/util/crypto/' in p or '/util/sync/' in p or any(x in n for x in ['databasekey','archivevault','vaultsecurity','backupflow','privatvault','privatevault']):return 'protection'
 if '/ui/speech/' in p or '/util/speech/' in p or n=='voicerecorddialog':return 'voice'
 if '/ui/screens/notes/' in p or '/data/note/' in p or n=='editordrafts':return 'notes'
 if '/util/assistant/' in p or '/ui/screens/chat/' in p or '/data/chat/' in p or any(x in n for x in ['bubblechat','ayvatalk','ayvadialogue','offlinenlu','ayvaintent','ayvachatcommand','ayvacompound','ayvacontext','chatconversation','chattaskdraft']):return 'chat'
 if any(x in n for x in ['habit']):return 'habits'
 if '/data/drill/' in p or '/ui/screens/drill/' in p or any(x in n for x in ['aptitude','arithmetic','drill','vocab']):return 'learning'
 if any(x in n for x in ['account','economy','dailyquest','mystery','chest','smokepaw','profileavatar','gamification','licensemanager','subscription']):return 'profile'
 if any(x in n for x in ['task','todo','smartdate','worksession','workreminder','planningeditor','productivitylibrary','timeview']):return 'tasks'
 if '/ui/theme/' in p or any(x in n for x in ['settings','permissions','permission','apptheme','appicon','vizag','layeredvizag','legacywebp','preferenceshub','screenprotection']):return 'settings'
 if any(x in n for x in ['focus','restrict','block','schedule','temporar','usage','appcatalog','appmode','boundary','timescreen','streakmanager']):return 'focus'
 if '/service/' in p or n in ['safeprefsextensions','talkaction']:return 'platform'
 if p.endswith(('mainactivity.kt','focusapplication.kt')) or '/ui/navigation/' in p or n=='focusbottombar':return 'shell'
 if '/assets/' in p or '/res/' in p:return 'assets'
 return 'shell'
def kind(p):
 if p.startswith('app/src/main/java/'):return 'Production Kotlin'
 if p.startswith('app/src/test/') or p.startswith('app/src/androidTest/'):return 'Tests'
 if '/assets/' in p:return 'Bundled assets'
 if '/res/' in p:return 'Android resources'
 if '/jniLibs/' in p:return 'Bundled native code'
 if '/schemas/' in p:return 'Database schema snapshots'
 if p.startswith('docs/') or p.endswith('.md'):return 'Documentation'
 if p.startswith('tools/') or p.startswith('.github/') or any(x in p for x in ['gradle','proguard']):return 'Build and tools'
 return 'Project metadata'
def human(n):return re.sub(r'(?<=[a-z0-9])(?=[A-Z])',' ',n).replace('_',' ')
def generic(p,txt):
 n=Path(p).stem;h=human(n);m=LABELS[module(p)]
 if kind(p)=='Production Kotlin':
  suffix={'Dao':'Database query interface for ','Repository':'Data access and update boundary for ','ViewModel':'Reactive screen state and operations for ','Screen':'User-interface screen for ','Activity':'Android window / activity entry point for ','Receiver':'Handles Android broadcasts or scheduled callbacks for ','Worker':'Deferred/background work for ','Provider':'Provider / update entry point for ','Config':'Configuration models and persistence for ','Store':'Persists and retrieves state for ','Parser':'Parses input into structured data for ','Language':'Recognizes supported language patterns for ','Database':'Room database schema / connection for ','Manager':'Coordinates operations and state for ','Helper':'Supporting functions for ','Engine':'Core transformation or evaluation routines for ','Dialog':'Dialog interface for '}
  for s,role in suffix.items():
   if n.endswith(s):return role+human(n[:-len(s)])+'.'
  return h+' component in '+m.lower()+'.'
 if kind(p)=='Tests':return 'Regression checks for '+human(n.removesuffix('Test'))+'. See extracted test-method names.'
 if kind(p)=='Database schema snapshots':return 'Exported Room schema evidence; supports migration review, not a live user database.'
 if '/dictionary/' in p and p.endswith('.dict'):return 'One compressed Wordset dictionary shard; runtime loads matching buckets on demand.'
 if p.endswith('.riv'):return 'Bundled Rive animation data; exact creator/download page not recorded in the current evidence.'
 if p.endswith('.lottie'):return 'Bundled dotLottie animation archive; runtime artwork, not the Lottie engine itself.'
 if p.endswith('.so'):return 'Prebuilt native dialogue executable/compatibility placeholder; rebuild source is in tools/experiments/chatscript.'
 if p.endswith('.ttf'):return 'Bundled typeface; inspect embedded copyright/license markers and retained notices.'
 if '/assets/' in p:return 'Packaged static asset: '+Path(p).name+'.'
 if '/res/layout/' in p:return 'Android XML layout used by RemoteViews or notifications.'
 if '/res/xml/' in p:return 'Android platform configuration / provider metadata.'
 if '/res/' in p:return 'Android resource ('+Path(p).parent.name+'): '+Path(p).name+'.'
 if p.startswith('docs/assistant/research/'):return 'Historical research / candidate assessment; not proof that a project shipped.'
 if p.startswith('docs/'):return 'Documentation or verification evidence: '+human(n)+'. Treat historical checkpoints separately from current code.'
 if p.startswith('tools/'):return 'Developer build, generation, packaging, or verification tool: '+human(n)+'.'
 return 'Project configuration / metadata: '+Path(p).name+'.'
OVERRIDES={
'FocusApplication.kt':'Process startup: restore recovery first, initialize managers, configure encrypted media loading and lazy databases.',
'MainActivity.kt':'Main Android window: wires navigation, primary screens, bottom dock and settings destinations.',
'FocusBottomBar.kt':'Five-slot bottom dock. Its fourth slot is a blank placeholder; Habits and Routines are reached elsewhere.',
'Screen.kt':'Route-name registry. The route named empty opens Notes; empty_tab is the blank placeholder.',
'SettingsDestinations.kt':'Registers the shared settings routes, search wrappers and legacy-route redirects.',
'FocusBlockerService.kt':'Monitors foreground app usage and focus/routine state; decides when direct blocking overlays are needed.',
'BlockOverlayManager.kt':'Builds hard/soft blocking windows using WindowManager overlays; this is the primary blocker presentation.',
'BlockActivity.kt':'Manifest-declared alternate blocking Activity. Do not confuse it with the primary direct-overlay service path.',
'FocusSessionManager.kt':'Restores and tracks the focus timer deadline; timer completion does not control phone-wide DND.',
'FocusSessionEndReceiver.kt':'Receives the focus-end alarm and completes the timer outside the visible screen.',
'UnifiedOverlayCoordinator.kt':'Queues competing reminder overlays so task/habit windows do not replace one another unpredictably.',
'ReminderOverlayStore.kt':'Persists/reconstructs pending reminder overlay presentation state.',
'TaskReminderHelper.kt':'Schedules/cancels task reminders and updates notification summaries.',
'TaskNotifications.kt':'Separates task notification identities from service notifications with full task-ID tags.',
'BootReceiver.kt':'Restores optional services and enqueues reminder reconciliation after boot or app update.',
'ReminderClockReceiver.kt':'Responds to local time/timezone changes by scheduling reminder reconciliation.',
'ReminderReconcileWorker.kt':'Rebuilds reminder schedules, isolating failures; calendar changes preserve absolute task timestamps.',
'HabitPause.kt':'Pause intervals and pause-aware habit behavior; paused time is not fabricated completion.',
'HabitAlarmScheduler.kt':'Computes and registers habit reminder windows; pause/resume affects scheduling.',
'NoteEntity.kt':'Stored note model, checklist/media references, privacy flags and editor content fields.',
'NotesViewModel.kt':'Coordinates note screen state, editing, archive/vault actions and repository operations.',
'KeepNoteEditor.kt':'Main note-editing UI; text, blocks, formatting and attachment entry points.',
'NotesnookBlockModel.kt':'App block-document representation. The filename alone does not prove code was copied from Notesnook.',
'RichTextEngine.kt':'Rich-text transformations and formatting state used by the note editor.',
'NoteMediaManager.kt':'Imports/manages note attachments and their storage references.',
'NoteImageHelper.kt':'Image import/decoding helpers; image safety and dimensions are separate from editor styling.',
'EncryptedMediaStorage.kt':'Encrypts original local attachments using AES-GCM with an AndroidKeyStore-held key; legacy reads are distinct.',
'EncryptedMediaFetcher.kt':'Coil bridge for decrypting encrypted note attachments for display.',
'ArchiveVaultSecurity.kt':'Private archived-note PIN/recovery handling; derives wrapping keys and manages a stable vault data key.',
'DatabaseKeyProvider.kt':'Creates/unwraps the SQLCipher passphrase using AndroidKeyStore protection; it is not the user backup password.',
'VaultPayloadEncryptor.kt':'Encrypts/decrypts the private note payload with the active vault subkey.',
'CryptoBackupEngine.kt':'Portable password-protected backup envelope: current Argon2id + AES-GCM, with legacy readers.',
'SnapshotCryptoEngine.kt':'Device-key AES-GCM envelope for internal snapshots and protected state files; not a portable password backup.',
'BackupRestoreManager.kt':'Collects/export/restores application data and media; validates/stages before applying live changes.',
'RestoreStaging.kt':'Prepares bounded validated restore content before live mutation.',
'RestoreJournal.kt':'Crash-recovery journal: completes or rolls back interrupted restore operations at startup.',
'MaintenanceGate.kt':'Coordinates participating writers during maintenance; not a second database or encryption algorithm.',
'MaintenanceOpenHelperFactory.kt':'Wraps SQLite access in the maintenance barrier. Without a SQLCipher delegate it does not encrypt a database.',
'DataSafetyManager.kt':'Schedules and manages internal safety snapshots and recovery evidence.',
'ExportCleanupWorker.kt':'Removes expired temporary plaintext exports; intentional sharing is separate from encrypted original storage.',
'VaultSyncManager.kt':'Serializes/restores note/task vault payloads. The name does not establish a running network sync service.',
'VaultCryptoEngine.kt':'Cryptographic packaging/key handling for the vault-transfer path; distinct from full-app backup envelopes.',
'OnDeviceTranscriber.kt':'Uses the default phone SpeechRecognizer; despite the name, the selected provider may use online recognition.',
'SpeechServiceDiagnostics.kt':'Reports which speech services are available/configured; diagnostic Google package visibility is not bundled Google code.',
'VoiceCaptureContent.kt':'Shared transcription popup UI, editable draft transcript and capture controls.',
'VoiceVisualization.kt':'Renders voice amplitude/motion visuals; this is presentation rather than speech recognition.',
'BubbleChatActivity.kt':'Chat activity and integration shell: composer, message cards, actions and assistant entry point.',
'OfflineAssistant.kt':'Main offline assistant turn coordinator; selects supported modes/features and guarded action proposals.',
'AyvaIntentRouter.kt':'Routes interpreted input toward task/native actions/Talk paths; review precedence alongside OfflineAssistant.',
'AssistantActionExecutor.kt':'Guarded execution owner for assistant-requested changes and undo; response text is not write authority.',
'AssistantSession.kt':'Conversation references, pending actions, confirmations and protected session persistence.',
'ChatExperiences.kt':'Focused offline experiences: games, facts, jokes, encouragement, stories and resumable experience state.',
'ExperienceContent.kt':'Authored finite entertainment content, source-linked facts and original traditional-fable retellings.',
'AssistantDictionaryStore.kt':'Reads bounded gzip dictionary shards and editorial sense data; not a cloud dictionary.',
'NativeGeneralDialogue.kt':'Optional pinned ChatScript subprocess adapter; trusted packaged rules only, same app UID, Kotlin fallback.',
'GeneralDialogue.kt':'Coordinates bounded general-dialogue interpretation and fallback; not unrestricted model-based conversation.',
'TripChecklistConversation.kt':'Trip/exam checklist conversation state, incremental additions/edits, dates, summaries and completion handling.',
'ConversationPlanStore.kt':'Persists/commits planning workspaces with canonical task links and operation receipts.',
'AssistantPlanStore.kt':'Assistant plan persistence/commit boundary with existing task integration.',
'AssistantStateLock.kt':'Serializes assistant state access; complements database transactions and maintenance gates.',
'BubbleChatManager.kt':'Chat transcript cache and serialized Room persistence, unread counts, startup merge and restore invalidation.',
'BubbleIconManager.kt':'Shares the existing app icon artwork with the bubble; persists its separate choice and notifies the running overlay without restarting it.',
'BubbleIconPicker.kt':'Compact chat-menu picker for the 12 existing app icons; highlights the saved bubble selection and applies on tap.',
'BubbleService.kt':'Floating chat bubble: foreground lifetime, snooze/visibility, fullscreen/landscape hiding and recovery.',
'ChatLifecycle.kt':'Suspends hidden chat projection and stabilizes viewed timestamps when UI visibility changes.',
'SmartDateParser.kt':'Shared supported natural-language date parsing; role/context decisions remain with the caller.',
'AptitudeManager.kt':'Learning profile, drill statistics and progress persistence.',
'ArithmeticEngine.kt':'Generates/evaluates supported arithmetic learning questions and explanations.',
'VocabDatabase.kt':'Room vocabulary database seeded from vocab.db; distinct from the large Wordset shard dictionary.',
'AyvaChatDatabase.kt':'App-private Room SQLite transcript/drill-state database; no SQLCipher delegate is configured here.',
'DrillDatabase.kt':'App-private Room SQLite drill-session summaries; separate from the encrypted notes/focus stores.',
'FocusDatabase.kt':'Room schema for restrictions, routines, tasks, habits/logs and assistant receipts; encrypted via FocusApplication.',
'NoteDatabase.kt':'SQLCipher-backed note database with explicit migration/recovery handling.',
'FocusEconomyManager.kt':'Gold/level/avatar economy and profile reward state.',
'DailyQuestManager.kt':'Quest/chest eligibility and award calculation; visual Skip/Collect must not roll another reward.',
'SmokePawChestScene.kt':'Private offline HTML/vector rasterizer bridge for the approved tiered chest animation.',
'DuolingoMysteryChestDialog.kt':'Native chest dialog, reveal lifecycle and reward presentation.',
'LicenseManager.kt':'Local signed lifetime-Pro token verification; no Google Play Billing SDK is used by this component.',
'SettingsSearchCatalog.kt':'Canonical settings labels/aliases and destinations for in-app search.',
'SettingsVizagFooter.kt':'Chooses/hosts the nine Vizag scenery variants and signature link.',
'LayeredVizagDrawable.kt':'Native independent-motion renderer for the five replaced Vizag scenes.',
'LegacyWebpDrawable.kt':'Playback path for retained older animated WebP scenes.',
'WidgetEditorComponents.kt':'Shared compact customization rows, radio-choice dialogs, sliders, tabs and optional live previews.',
'NoteWidgetTypography.kt':'Explicit note-widget text sizing rules; avoids auto-sizing surprises in RemoteViews.',
'NoteWidgetProvider.kt':'Updates the note widget RemoteViews and attaches actions/content adapters.',
'TodoWidgetProvider.kt':'Updates task widget RemoteViews, tabs and row actions.',
'ExamCountdown.kt':'Countdown model/validation and portable event storage; launcher widget IDs remain local bindings.',
'ExamCountdownProvider.kt':'Countdown widget rendering, clock/date updates and pin callback handling.'}
# Snapshot inventory; contents remain outside the repository.
records=[]; code_text={}; symbolmap=collections.defaultdict(list)
for p in TRACKED:
 full=ROOT/p
 if not full.is_file():continue
 b=full.read_bytes();istext=p.endswith(('.kt','.java','.py','.kts','.xml','.md','.txt','.yml','.yaml','.toml','.cpp','.h','.js','.html','.patch','.json','.properties','.gradle')) or p in ['LICENSE','gradlew']
 txt=b.decode('utf-8',errors='replace') if istext else ''
 role=OVERRIDES.get(Path(p).name,generic(p,txt))
 d={'path':p,'name':Path(p).name,'kind':kind(p),'module':module(p),'role':role,'summary_basis':'reviewed file map' if Path(p).name in OVERRIDES else 'indexed / inferred from name and declarations','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'url':f'https://github.com/Nrajesh0/Ayva/blob/{COMMIT}/{p}','symbols':[],'functions':[],'references':[],'used_by':[],'resources':[],'asset_refs':[],'provenance':'project inventory; origin not independently established','license':'Declared project AGPLv3; confirm individual provenance'}
 if 'proprietary and confidential' in txt:
  d['license']='AGPLv3 at root conflicts with restrictive file header';d['license_status']='conflict'
 else:d['license_status']='declared'
 if p.startswith(BASE) and p.endswith('.kt'):
  code_text[p]=txt
  pkg=re.search(r'^package\s+([\w.]+)',txt,re.M);d['package']=pkg.group(1) if pkg else ''
  decls=[]
  for m in re.finditer(r'^(?P<indent>[ \t]*)(?:(?:public|private|internal|protected|data|sealed|enum|open|abstract|value|annotation|expect|actual)\s+)*(?P<type>class|object|interface)\s+(?P<name>\w+)',txt,re.M):
   if m.group('name') not in ['Companion'] and len(m.group('indent'))<=4:decls.append({'name':m.group('name'),'kind':m.group('type'),'line':txt[:m.start()].count('\n')+1})
  for m in re.finditer(r'^(?P<indent>[ \t]*)(?:(?:public|private|internal|protected|suspend|override|inline|tailrec|operator|infix)\s+)*fun\s+(?:<[^>]+>\s*)?(?:[\w<>?.]+\.)?(?P<name>\w+)\s*\(',txt,re.M):
   item={'name':m.group('name'),'line':txt[:m.start()].count('\n')+1};d['functions'].append(item)
   if not m.group('indent'):decls.append({**item,'kind':'top-level function'})
  d['symbols']=decls
  for s in decls:symbolmap[d['package']+'.'+s['name']].append(p)
  d['line_count']=len(txt.splitlines())
 if '/assets/dictionary/' in p:
  d.update(license='CC BY-SA 4.0 + retained WordNet notice',license_status='documented',provenance='Wordset Dictionary, commit 4503bfafbe4556361a296b9d368c18168dfb56c3; editorial adaptations labelled separately')
 if p=='app/src/main/assets/vocab.db':d.update(license='Not established in repository documentation',license_status='unknown',provenance='Legacy vocabulary seed; docs/assistant/DICTIONARY_DATA.md explicitly records a provenance gap')
 if '/assets/conversation/' in p or '/assets/licenses/chatscript/' in p or '/jniLibs/' in p:
  d.update(license='ChatScript MIT / WordNet notice / LLVM notices by component',license_status='documented',provenance='Pinned ChatScript 9f5eec4736ba22bd992a6498c1e0052e2a795125 + project rule pack; source/build scripts in tools/experiments/chatscript')
 if p.endswith('.lottie'):
  d.update(license='Exact file terms unverified; Lottie Simple License may apply if its original source qualifies',license_status='unknown',provenance='Downloaded animation; exact page/creator missing from current file evidence')
  try:
   with zipfile.ZipFile(full) as z:d['embedded_metadata']=json.loads(z.read('manifest.json'))
  except Exception:pass
 if p=='app/src/main/res/raw/cat_animation.json':d.update(license='Exact artwork license unverified',license_status='unknown',provenance='Raw cat animation JSON; original creator/item page and distribution terms need verification')
 if p.endswith('.riv'):d.update(license='Exact file terms unverified; public Rive Community Content is CC BY 4.0 under current terms',license_status='unknown',provenance='Downloaded Rive file; creator/download page must be recovered separately from MIT runtime license')
 if p.endswith('.ttf'):
  try:
   from fontTools.ttLib import TTFont
   f=TTFont(full);metadata={str(i):sorted({n.toUnicode() for n in f['name'].names if n.nameID==i}) for i in [0,13,14]};f.close();d['font_metadata']=metadata
   markers=' '.join(metadata['13']+metadata['14']);lic='Apache 2.0 marker' if 'apache' in markers.lower() else 'SIL Open Font License marker' if 'ofl' in markers.lower() or 'openfontlicense' in markers.lower() else 'Unresolved font terms'
   d.update(license=lic+'; retain authors/notices and verify source file',license_status='documented',provenance='Embedded font name-table license/copyright markers; Allura notice additionally bundled')
  except Exception:pass
 if p.startswith('docs/assistant/research/'):d['provenance']='Research candidate list; not evidence of shipped dependency'
 if 'Notesnook' in Path(p).name:d['provenance']='Name suggests influence; direct copying is not established by the filename or current attribution evidence'
 if p=='app/src/main/assets/smoke_paw_chest.html':d['provenance']='Project vector scene; approved Smoke Paw design described in docs/animation/SMOKE_PAW_MYSTERY_BOXES.md'
 if p.startswith(('tools/vizag_replacements/','app/src/main/res/raw/vizag_')):d['provenance']='Project scenery/export pipeline; exact artistic rights/brand scope still needs confirmation'
 records.append(d)
by_path={r['path']:r for r in records};byname=collections.defaultdict(list)
for r in records:byname[r['name']].append(r['path'])
unique={fq.split('.')[-1]:ps[0] for fq,ps in symbolmap.items() if len(ps)==1 and len(fq.split('.')[-1])>3}
# Ambiguous short symbols do not become speculative edges.
shortowners=collections.defaultdict(set)
for fq,ps in symbolmap.items():shortowners[fq.split('.')[-1]].update(ps)
unique={k:next(iter(v)) for k,v in shortowners.items() if len(v)==1 and len(k)>3}
resource_map=collections.defaultdict(list)
for r in records:
 p=r['path'];parts=Path(p).parts
 if p.startswith('app/src/main/res/') and len(parts)>5:
  folder=parts[4].split('-')[0]
  if folder!='values':resource_map[(folder,Path(p).stem)].append(p)
  elif p.endswith('.xml'):
   try:
    for node in ET.fromstring((ROOT/p).read_text()):
     name=node.attrib.get('name');typ=node.attrib.get('type',node.tag)
     if name:resource_map[(typ,name)].append(p)
   except ET.ParseError:pass
for path,txt in code_text.items():
 r=by_path[path];refs={};clean=re.sub(r'"""[\s\S]*?"""|/\*[\s\S]*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"',' ',txt)
 for fq in re.findall(r'^import\s+(com\.focusbyrj\.app\.[\w.]+)',txt,re.M):
  for owner in symbolmap.get(fq,[]):
   if owner!=path:refs[owner]='explicit import'
 for token in set(re.findall(r'\b[A-Za-z_]\w+\b',clean)):
  owner=unique.get(token)
  if owner and owner!=path and owner not in refs:refs[owner]='static identifier reference'
 r['references']=[{'path':p,'basis':b} for p,b in sorted(refs.items())]
 for p,b in refs.items():by_path[p]['used_by'].append({'path':path,'basis':b})
 res=set()
 for typ,name in re.findall(r'\bR\.(\w+)\.(\w+)',txt):res.update(resource_map.get((typ,name),[]))
 r['resources']=sorted(res)
 for target in records:
  if target['path'].startswith('app/src/main/assets/') and target['name'] in txt:r['asset_refs'].append(target['path'])
for r in records:
 if r['path'].startswith(('app/src/test/','app/src/androidTest/')):
  txt=(ROOT/r['path']).read_text(errors='replace');r['functions']=[{'name':m.group(1),'line':txt[:m.start()].count('\n')+1} for m in re.finditer(r'\bfun\s+(\w+)\s*\(',txt)]
  r['line_count']=len(txt.splitlines())
# Android components and route catalogue.
ns='{http://schemas.android.com/apk/res/android}';tools='{http://schemas.android.com/tools}'
manifest=ET.parse(ROOT/'app/src/main/AndroidManifest.xml').getroot();components=[];permissions=[]
for n in manifest.findall('uses-permission'):permissions.append({'name':n.attrib.get(ns+'name'),'removed':n.attrib.get(tools+'node')=='remove'})
for n in manifest.find('application'):
 if n.tag in ['activity','activity-alias','service','receiver','provider']:
  name=n.attrib.get(ns+'name','');source=byname.get(name.split('.')[-1]+'.kt',[])
  components.append({'kind':n.tag,'name':name,'exported':n.attrib.get(ns+'exported','unspecified'),'target':n.attrib.get(ns+'targetActivity'),'source':source[0] if len(source)==1 else None,'removed':n.attrib.get(tools+'node')=='remove','actions':[e.attrib.get(ns+'name') for e in n.findall('./intent-filter/action')]})
nav=(ROOT/(BASE+'ui/navigation/Screen.kt')).read_text();routes=[{'symbol':a,'route':b,'label':c} for a,b,c in re.findall(r'object\s+(\w+)\s*:\s*Screen\("([^"]+)",\s*"([^"]+)"',nav)]
settings=(ROOT/(BASE+'ui/navigation/SettingsDestinations.kt')).read_text();settingsroutes=re.findall(r'composable\("([^"]+)"\)',settings)
config=tomllib.loads((ROOT/'gradle/libs.versions.toml').read_text());dependencies=[];build=(ROOT/'app/build.gradle.kts').read_text()
for line in build.splitlines():
 m=re.search(r'\b(implementation|ksp|testImplementation|androidTestImplementation|debugImplementation)\((.+)\)',line)
 if not m:continue
 scope,raw=m.groups();coord=None
 if raw.startswith('"'):coord=raw.split('"')[1]
 else:
  alias=re.search(r'libs\.([\w.]+)',raw)
  if alias:
   key=alias.group(1).replace('.','-');entry=config.get('libraries',{}).get(key,{})
   v=entry.get('version','BOM-managed');v=config['versions'].get(v.get('ref'),'?') if isinstance(v,dict) else v
   coord=':'.join([entry.get('group','?'),entry.get('name',key),v])
 dependencies.append({'scope':scope,'declaration':raw,'coordinate':coord or raw,'url':'https://central.sonatype.com/search?q='+((coord or '').split(':')[0])})
version=re.search(r'versionName\s*=\s*"([^"]+)"',build).group(1);code=int(re.search(r'versionCode\s*=\s*(\d+)',build).group(1))
counts={'tracked_files':len(records),'production_kotlin':len(code_text),'test_files':sum(r['kind']=='Tests' for r in records),'asset_files':sum(r['kind']=='Bundled assets' for r in records),'resource_files':sum(r['kind']=='Android resources' for r in records),'conflicting_production_headers':sum(r.get('license_status')=='conflict' and r['path'].startswith('app/src/main/') for r in records),'static_file_edges':sum(len(r['references']) for r in records),'manifest_components':len(components),'launcher_aliases':sum(c['kind']=='activity-alias' for c in components)}
data={'title':'RUN — Visual Architecture Atlas','date':'3 November 2026','timezone':'UTC','version':version,'version_code':code,'commit':COMMIT,'repo':'https://github.com/Nrajesh0/Ayva','counts':counts,'module_labels':LABELS,'files':records,'components':components,'permissions':permissions,'routes':routes,'settings_routes':settingsroutes,'dependencies':dependencies,'methodology':'Complete tracked-file inventory, reviewed feature maps and static reference extraction. Identifier edges indicate possible source coupling, not measured execution. Long-tail file roles are indexed/inferred. Asset authorship and legal rights are asserted only where evidence is recorded. The documentation generator does not modify app code.'}
(OUT/'atlas-data.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
with (OUT/'RUN-file-index.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['Path','Category','Feature area','Role','Description basis','License / status','Origin evidence','Source URL','Bytes','SHA256'])
 for r in records:w.writerow([r['path'],r['kind'],LABELS[r['module']],r['role'],r['summary_basis'],r['license'],r['provenance'],r['url'],r['bytes'],r['sha256']])
with (OUT/'RUN-code-connections.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['Source file','Referenced file','Evidence type'])
 for r in records:
  for edge in r['references']:w.writerow([r['path'],edge['path'],edge['basis']])
print(json.dumps({'version':version,'commit':COMMIT,'counts':counts,'module_counts':dict(collections.Counter(r['module'] for r in records if r['kind']=='Production Kotlin'))},indent=2))
