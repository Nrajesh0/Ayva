from pathlib import Path
import json,asyncio,csv,re,subprocess
from playwright.async_api import async_playwright
OUT=Path('/workspace/artifacts/run-atlas')
async def run():
 checks={};errors=[];requests=[]
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--allow-file-access-from-files'])
  page=await browser.new_page(viewport={'width':1450,'height':1000},device_scale_factor=1)
  page.on('pageerror',lambda e:errors.append(str(e)))
  await page.route('http://**/*',lambda route:route.abort());await page.route('https://**/*',lambda route:route.abort())
  page.on('request',lambda r:requests.append(r.url) if r.url.startswith(('http:','https:')) else None)
  await page.set_content((OUT/'RUN-Visual-Guide.html').read_text(),wait_until='load')
  await page.wait_for_selector('#file-results .file-row')
  checks['html_standalone_no_network_requests']=len(requests)==0
  checks['initial_file_count']=await page.locator('#result-count').inner_text()
  checks['html_unique_ids']=await page.evaluate('(()=>{const ids=[...document.querySelectorAll("[id]")].map(n=>n.id);return ids.length===new Set(ids).size})()')
  checks['broken_internal_anchors']=await page.evaluate('Array.from(document.links).map(n=>n.getAttribute("href")).filter(h=>h&&h.startsWith("#")&&!document.getElementById(h.slice(1)))')
  await page.screenshot(path=str(OUT/'images'/'html-desktop.png'),full_page=False)
  await page.locator('#query').fill('NoteDatabase');await page.wait_for_timeout(100)
  checks['search_note_database']=await page.locator('#result-count').inner_text()
  await page.locator('button[data-open="app/src/main/java/com/focusbyrj/app/data/note/NoteDatabase.kt"]').first.click()
  checks['file_inspector']=await page.locator('#file-title').inner_text()=='NoteDatabase.kt'
  checks['inspector_reverse_references']=await page.locator('#detail-body').inner_text()
  checks['inspector_reverse_references']='Used by' in checks['inspector_reverse_references'] and 'NotesViewModel' in checks['inspector_reverse_references']
  await page.screenshot(path=str(OUT/'images'/'html-file-inspector.png'))
  await page.locator('#close-detail').click();await page.locator('#reset-search').click()
  await page.locator('#license-filter').select_option('unknown')
  checks['unknown_rights_filter']=await page.locator('#result-count').inner_text()
  await page.locator('#reset-search').click();await page.locator('#query').fill('restore')
  checks['feature_search_restore']=await page.locator('#result-count').inner_text()
  await page.locator('#reset-search').click()
  # A graph node link should open the local inspector, not navigate away.
  await page.locator('#ui-map svg a').first.click()
  checks['diagram_click_opens_inspector']=not await page.locator('#drawer').is_hidden()
  await page.locator('#close-detail').click()
  await page.evaluate('window.scrollTo(0,0)')
  await page.emulate_media(media='print')
  await page.pdf(path=str(OUT/'RUN-Visual-Guide.pdf'),format='A4',print_background=True,prefer_css_page_size=True,display_header_footer=True,header_template='<div></div>',footer_template='<div style="width:100%;font-family:Arial;font-size:8px;color:#617784;padding:0 56px;display:flex;justify-content:space-between"><span>RUN · Visual architecture atlas · v2.0.37 · 03 Nov 2026</span><span><span class="pageNumber"></span> / <span class="totalPages"></span></span></div>',outline=True,tagged=True)
  await page.emulate_media(media='screen')
  await page.set_viewport_size({'width':390,'height':844})
  await page.locator('#ui-map').scroll_into_view_if_needed()
  await page.screenshot(path=str(OUT/'images'/'html-mobile.png'))
  checks['mobile_no_horizontal_overflow']=await page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1')
  checks['js_errors']=errors
  await browser.close()
 (OUT/'html-validation.json').write_text(json.dumps(checks,indent=2))
 print(json.dumps(checks,indent=2))
asyncio.run(run())
