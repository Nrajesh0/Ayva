from pathlib import Path
import collections,csv,hashlib,json,re,shutil,subprocess,zipfile
import fitz
OUT=Path('/workspace/artifacts/run-atlas');ROOT=Path('/workspace/Ayva');DEST=ROOT/'docs/app-atlas'
d=json.loads((OUT/'atlas-data.json').read_text());rs=d['files'];commit=d['commit']
tracked=subprocess.check_output(['git','ls-tree','-r','--name-only',commit],cwd=ROOT,text=True).splitlines()
assert len({r['path'] for r in rs})==len(rs)
assert {r['path'] for r in rs}==set(tracked)
assert all((ROOT/r['path']).is_file() and hashlib.sha256((ROOT/r['path']).read_bytes()).hexdigest()==r['sha256'] for r in rs)
assert all(r['url']==f"{d['repo']}/blob/{commit}/{r['path']}" for r in rs)
assert all(e['path'] in set(tracked) for r in rs for e in r['references'])
assert all(1<=m['line']<=r['line_count'] for r in rs for m in r.get('functions',[]) if r.get('line_count'))
assert all(r['path']=='app/src/main/res/raw/cat_animation.json' for r in rs if r['provenance'].startswith('Raw cat animation JSON'))
prods=[r for r in rs if r['kind']=='Production Kotlin'];assert len(prods)==d['counts']['production_kotlin']
html=(OUT/'RUN-Visual-Guide.html').read_text();assert html.count('<article class="file-entry">')==len(prods)
assert '<script src=' not in html and 'https://cdn.' not in html
pdf=fitz.open(OUT/'RUN-Visual-Guide.pdf');text='\n'.join(p.get_text() for p in pdf)
assert all(r['name'] in text for r in prods)
assert 'BubbleIconManager.kt' in text and 'F-Droid: change what to what' in text
assert '1,109' in text and '396 production' in text
assert all(len(p.get_text().strip())>100 for p in pdf)
assert all(span['bbox'][0]>=-1 and span['bbox'][2]<=page.rect.width+1 for page in pdf for b in page.get_text('dict')['blocks'] if 'lines' in b for line in b['lines'] for span in line['spans'])
with (OUT/'RUN-file-index.csv').open() as f:assert sum(1 for _ in csv.DictReader(f))==len(rs)
with (OUT/'RUN-code-connections.csv').open() as f:assert sum(1 for _ in csv.DictReader(f))==d['counts']['static_file_edges']
web=json.loads((OUT/'html-validation.json').read_text());assert web['html_unique_ids'] and not web['js_errors'] and not web['broken_internal_anchors'] and web['mobile_no_horizontal_overflow']
checks={'source_snapshot':commit,'source_version':d['version'],'snapshot_tracked_files':len(rs),'production_code_files':len(prods),'catalog_covers_every_production_file':True,'inventory_complete_and_unique':True,'file_hashes_verified':True,'method_line_bounds_verified':True,'static_source_edges':d['counts']['static_file_edges'],'diagram_count':len(list((OUT/'diagrams').glob('*.svg'))),'pdf_pages':len(pdf),'pdf_bytes':(OUT/'RUN-Visual-Guide.pdf').stat().st_size,'pdf_catalog_filenames_complete':True,'pdf_has_searchable_text_and_links':True,'pdf_spans_within_horizontal_page_bounds':True,'no_blank_pdf_pages':True,'html':web,'app_validation':{'compileDebugKotlin':'passed','compileDebugUnitTestKotlin':'passed','device_tests':'not run','full_suite':'not run for this low-impact feature','official_fdroid_build':'not run'},'limits':'Static source edges are extracted hints, not observed execution. Long-tail roles are inferred and labelled. Legal rights are not certified. Current primary-source pages do not establish historical item download terms.'}
(OUT/'atlas-validation.json').write_text(json.dumps(checks,indent=2))
readme=f'''RUN visual architecture atlas
=============================
Snapshot: {commit}
Version: {d['version']} / {d['version_code']} | prepared 3 November 2026

Open RUN-Visual-Guide.html in a browser for search, directory trees, clickable
feature maps and per-file details. It is self-contained and needs no server or
internet connection. Source/reference links require internet when clicked.
A browser configured to block local HTML may require a permitted local viewer.

Open RUN-Visual-Guide.pdf for the {len(pdf)}-page reading copy. It contains vector
maps, searchable text, source links, and a catalog of all {len(prods)} production
Kotlin files. The HTML/CSV index includes all {len(rs)} tracked files at the pinned
snapshot, not only Kotlin. Files subsequently added to publish this atlas are
not retroactively included in that source snapshot.

RUN-file-index.csv: all tracked files, roles, origin/license evidence and hashes.
RUN-code-connections.csv: extracted static coupling hints, not a runtime graph.
RUN-material-ledger.csv: exact artwork/font/data evidence and fields to complete.
atlas-data.json: declarations, methods, forward/reverse references and manifest.
feature-maps.json: reviewed feature/flow/provenance/F-Droid narrative.
atlas-validation.json: actual document checks and their limits.
diagrams/: editable DOT maps and the resulting SVGs.
source/: Python inventory, narrative, renderer and browser/PDF validation.

Rebuilding: requires the matching RUN Git checkout, Python 3.12 with Pillow,
fontTools, Playwright, PyMuPDF, plus Graphviz (dot) and system Chromium. The
scripts default to /workspace/Ayva and /workspace/artifacts/run-atlas; update
ROOT/OUT if using other paths. Run inventory.py, build_atlas.py, render_verify.py.
Screenshot fixtures referenced by build_atlas.py are generated local reports,
not git-tracked app assets; if absent, use the matching screenshot tests/reports
or adapt the fixture section. Generator reproduction is not an F-Droid build.
Do not rerun historical layout patchers; none are part of this bundle.

The app icon picker is implemented in the pinned source. Guide generation itself
does not edit app behavior, migrations or user data. No signing keys, credentials,
real user databases or full third-party animation binaries are in this bundle.
Rights marked unknown need source evidence; no license certification is implied.
The PDF/HTML are analysis documents, not a formal security audit or guaranteed
F-Droid acceptance. Review the dated source evidence and maintainer requirements.
'''
(OUT/'README.txt').write_text(readme)
files=['RUN-Visual-Guide.pdf','RUN-Visual-Guide.html','RUN-file-index.csv','RUN-code-connections.csv','RUN-material-ledger.csv','atlas-data.json','feature-maps.json','atlas-validation.json','README.txt']
sourcefiles=['inventory.py','content.py','build_atlas.py','render_verify.py','finalize_bundle.py']
# Keep the package useful and small: source maps and data, not old renders/logs.
with zipfile.ZipFile(OUT/'RUN-Visual-Guide-bundle.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name in files:z.write(OUT/name,arcname=name)
 for name in sourcefiles:z.write(OUT/'source'/name,arcname='source/'+name)
 for pa in sorted((OUT/'diagrams').iterdir()):
  if pa.suffix in ['.svg','.dot']:z.write(pa,arcname='diagrams/'+pa.name)
with zipfile.ZipFile(OUT/'RUN-Visual-Guide-bundle.zip') as z:
 assert z.testzip() is None
 assert all(not n.startswith(('/', '../')) and '..' not in Path(n).parts for n in z.namelist())
DEST.mkdir(parents=True,exist_ok=True)
for name in ['RUN-Visual-Guide.pdf','RUN-Visual-Guide.html','RUN-Visual-Guide-bundle.zip','RUN-file-index.csv','RUN-material-ledger.csv','atlas-validation.json']:
 shutil.copyfile(OUT/name,DEST/name)
(DEST/'README.md').write_text(f'''# RUN visual guide

[Read the PDF](RUN-Visual-Guide.pdf) · [Download the complete ZIP](RUN-Visual-Guide-bundle.zip) · [Interactive HTML](RUN-Visual-Guide.html)

Download and open the HTML locally to browse searchable file details, directory
trees and clickable connections. GitHub's HTML file preview displays its source.
Use the file page's download button for the offline guide.

The {len(pdf)}-page PDF covers 13 feature areas, 21 diagrams, UI navigation,
component responsibilities, storage/encryption, shared feature flows, material
provenance/license gaps and a concrete F-Droid preparation checklist. Its appendix
catalogs all {len(prods)} production Kotlin files. The complete bundle also includes
the {len(rs)}-file inventory, static references, editable diagrams, material ledger,
machine-readable data and generator scripts.

Source snapshot: [`{commit[:12]}`]({d['repo']}/tree/{commit}),
version {d['version']} / {d['version_code']}, 3 November 2026. This includes the
chat-menu bubble-icon picker using the 12 existing app icons. Generated atlas
publication files are outside the pinned source inventory.

Reviewed feature maps and inferred file roles are labelled separately. Static
references are source coupling hints, not measured execution. Missing references
are not evidence that a file can be removed safely. Unknown artwork/data origins
remain unresolved, not licensed by assumption. This is an analysis guide, not an
official F-Droid acceptance decision or formal security certification.

[Full file index](RUN-file-index.csv) · [Material/license worklist](RUN-material-ledger.csv) · [Validation record](atlas-validation.json)

The documentation is outside Android's source/resource/asset inputs and is not
packaged into the app. No app behavior changes are made by these generated files.
''')
print(json.dumps({'pdf_pages':len(pdf),'bundle_bytes':(OUT/'RUN-Visual-Guide-bundle.zip').stat().st_size,'tracked_file_inventory':len(rs),'code_files':len(prods),'destination':str(DEST),'validation':'passed'},indent=2))
