RUN visual architecture atlas
=============================
Snapshot: cce930915554c64c4884b134c238daed93e78155
Version: 2.0.37 / 137 | prepared 3 November 2026

Open RUN-Visual-Guide.html in a browser for search, directory trees, clickable
feature maps and per-file details. It is self-contained and needs no server or
internet connection. Source/reference links require internet when clicked.
A browser configured to block local HTML may require a permitted local viewer.

Open RUN-Visual-Guide.pdf for the 69-page reading copy. It contains vector
maps, searchable text, source links, and a catalog of all 396 production
Kotlin files. The HTML/CSV index includes all 1109 tracked files at the pinned
snapshot, not only Kotlin. Files subsequently added to publish this atlas are
not retroactively included in that source snapshot.

RUN-file-index.csv: all tracked files, roles, origin/license evidence and hashes.
RUN-code-connections.csv: extracted static coupling hints, not a runtime graph.
RUN-material-ledger.csv: exact artwork/font/data evidence and fields to complete.
atlas-data.json: declarations, methods, forward/reverse references and manifest.
feature-maps.json: reviewed feature/flow/provenance/F-Droid narrative.
atlas-validation.json: actual document checks and their limits.
diagrams/: editable DOT maps and the resulting SVGs.
source/: Python inventory, narrative, renderer and browser/PDF validation.

Rebuilding: requires the matching RUN Git checkout, Python 3.12 with Pillow,
fontTools, Playwright, PyMuPDF, plus Graphviz (dot) and system Chromium. The
scripts default to /workspace/Ayva and /workspace/artifacts/run-atlas; update
ROOT/OUT if using other paths. Run inventory.py, build_atlas.py, render_verify.py.
Screenshot fixtures referenced by build_atlas.py are generated local reports,
not git-tracked app assets; if absent, use the matching screenshot tests/reports
or adapt the fixture section. Generator reproduction is not an F-Droid build.
Do not rerun historical layout patchers; none are part of this bundle.

The app icon picker is implemented in the pinned source. Guide generation itself
does not edit app behavior, migrations or user data. No signing keys, credentials,
real user databases or full third-party animation binaries are in this bundle.
Rights marked unknown need source evidence; no license certification is implied.
The PDF/HTML are analysis documents, not a formal security audit or guaranteed
F-Droid acceptance. Review the dated source evidence and maintainer requirements.
